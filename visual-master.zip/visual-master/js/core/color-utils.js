/**
 * Hàm tiện ích màu sắc & cập nhật nền (hexToRgb, interpolateColor, updateDOMBackground, updatePlaylistBg).
 * (Trích từ file gốc, dòng 553-575 trong khối <script>)
 */
        function hexToRgb(hex) {
            let r = 0, g = 0, b = 0;
            if (hex.length == 4) { r = "0x" + hex[1] + hex[1]; g = "0x" + hex[2] + hex[2]; b = "0x" + hex[3] + hex[3]; } 
            else if (hex.length == 7) { r = "0x" + hex[1] + hex[2]; g = "0x" + hex[3] + hex[4]; b = "0x" + hex[5] + hex[6]; }
            return {r: +r, g: +g, b: +b};
        }

        function interpolateColor(color1, color2, factor) {
            const rgb1 = hexToRgb(color1); const rgb2 = hexToRgb(color2);
            let result = { r: Math.round(rgb1.r + factor * (rgb2.r - rgb1.r)), g: Math.round(rgb1.g + factor * (rgb2.g - rgb1.g)), b: Math.round(rgb1.b + factor * (rgb2.b - rgb1.b)) };
            return `rgb(${result.r}, ${result.g}, ${result.b})`;
        }

        function updateDOMBackground() { 
            if(!vizConfig.videoBgEnabled) document.body.style.backgroundColor = vizConfig.bgColor; 
            else document.body.style.backgroundColor = 'transparent';
        }
        
        function updatePlaylistBg() {
            if (vizConfig.bgImage) { playlistBg.style.backgroundImage = `url(${vizConfig.bgImage})`; playlistBg.style.filter = `blur(${vizConfig.bgBlur}px)`; } 
            else { playlistBg.style.backgroundImage = 'none'; playlistBg.style.filter = `blur(0px)`;}
        }
        
